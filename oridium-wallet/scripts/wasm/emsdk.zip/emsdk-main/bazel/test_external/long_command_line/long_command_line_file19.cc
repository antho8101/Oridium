#include "long_command_line_file19.hh"

#include <iostream>

void f19() { std::cout << "hello from f19()\n"; }
