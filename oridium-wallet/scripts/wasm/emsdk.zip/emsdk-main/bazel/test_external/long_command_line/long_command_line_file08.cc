#include "long_command_line_file08.hh"

#include <iostream>

void f8() { std::cout << "hello from f8()\n"; }
