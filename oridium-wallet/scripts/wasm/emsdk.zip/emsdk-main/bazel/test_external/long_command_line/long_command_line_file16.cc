#include "long_command_line_file16.hh"

#include <iostream>

void f16() { std::cout << "hello from f16()\n"; }
