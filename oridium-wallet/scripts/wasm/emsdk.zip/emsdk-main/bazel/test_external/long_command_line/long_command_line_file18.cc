#include "long_command_line_file18.hh"

#include <iostream>

void f18() { std::cout << "hello from f18()\n"; }
